package com.curso.testeNovoCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteNovoCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteNovoCrudApplication.class, args);
	}

}

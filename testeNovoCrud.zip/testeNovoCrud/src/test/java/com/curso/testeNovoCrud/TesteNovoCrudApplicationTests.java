package com.curso.testeNovoCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteNovoCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
